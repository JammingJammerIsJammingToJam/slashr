# /r
A work-in-progress programming language that aims to be simple with a small number of keywords.\
Originally a scratch project: https://scratch.mit.edu/projects/844829160/ \
For documentation, visit the wiki at https://github.com/JammingJammerIsJammingToJam/slashr/wiki/Documentation\