"""A Programming Language"""

__version__ = "1.0.0"