"""A Programming Language"""

__version__ = "1.0.1"
from .slashd import *